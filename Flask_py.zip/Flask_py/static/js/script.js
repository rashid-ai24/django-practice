document.addEventListener("DOMContentLoaded", () => {
    const heroContent = document.querySelector(".hero-content");
    if(heroContent) {
        heroContent.style.opacity = 0;
        heroContent.style.transition = "opacity 2s ease";
        setTimeout(() => { heroContent.style.opacity = 1; }, 500);
    }

    function handleForm(formId, url, responseId) {
        const form = document.getElementById(formId);
        const responseMsg = document.getElementById(responseId);

        if (!form) return; // Skip if form not on the page

        form.addEventListener("submit", (e) => {
            e.preventDefault(); // prevent page refresh

            const formData = new FormData(form);

            fetch(url, {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                responseMsg.textContent = data.message;
                if(data.message.toLowerCase().includes('error')){
                    responseMsg.classList.remove('success');
                    responseMsg.classList.add('error');
                } else {
                    responseMsg.classList.remove('error');
                    responseMsg.classList.add('success');
                }
                form.reset();

                // Fade out message after 5 seconds
                setTimeout(() => { responseMsg.textContent = ""; }, 5000);
            })
            .catch(error => {
                console.error("Error:", error);
                responseMsg.textContent = "An unexpected error occurred!";
                responseMsg.classList.remove('success');
                responseMsg.classList.add('error');
            });
        });
    }

    // Apply to multiple forms
    handleForm("ajaxForm", "/submit_ajax", "responseMessage");
    handleForm("contactForm", "/submit_contact", "contactResponse");

});