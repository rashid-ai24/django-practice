from flask import Flask, render_template, request, jsonify
from flask_mail import Mail,Message
from datetime import datetime
import csv

app = Flask(__name__)

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = 'moh.rashid.3557@gmail.com'
app.config['MAIL_PASSWORD'] = 'cxqd qtve cvjf mxyp'
app.config['MAIL_DEFAULT_SENDER'] = 'moh.rashid.3557@gmail.com'

mail=Mail(app)

@app.route('/')
def index():
    return render_template('index.html', title="Home Page")

@app.route('/about')
def about():
    return render_template('about.html', title="About Page")

@app.route('/submit_ajax', methods=['POST'])
def submit_ajax():
    username = request.form.get('username')
    email = request.form.get('email')
    message = f"Thank you {username}! Your email {email} has been received."
    return jsonify({'message': message})

@app.route('/contact')
def contact():
    return render_template("contact.html",title="Contact Page")

@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    try:
        # Get form data
        name = request.form.get('name')
        email = request.form.get('email')
        sub = request.form.get('subject')
        msg = request.form.get('message')
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Save to CSV
        with open('contact.csv', 'a', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow([timestamp, name, email, sub, msg])

        # Create email
        message = Message(
            subject=f"New Contact Form: {sub}",
            sender=app.config['MAIL_USERNAME'],   # must match your Gmail
            recipients=['moh.rashid20006@gmail.com'], 
            body=f"Name: {name}\nEmail: {email}\nMessage:\n{msg}\n\nTime: {timestamp}"
        )

        # Send email
        mail.send(message)

        return jsonify({'message': f"Thanks {name}, your message has been received and emailed!"})

    except Exception as e:
        # Catch errors and show in response
        return jsonify({'message': f"An error occurred: {e}"}), 500
    


if __name__ == "__main__":
    app.run(debug=True, threaded=True)